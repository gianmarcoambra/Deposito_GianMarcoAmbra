import java.util.ArrayList;
import java.util.Scanner;

public class Rubrica {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		ArrayList<Contatto> rubrica= new ArrayList<>();
		
		System.out.println("Quanti contatti vuoi inserire?");
		int numeroContatti = input.nextInt();
		input.nextLine();
		
		for(int i = 0; i<numeroContatti; i++) {
			
			System.out.println("\ncontatto: "+ (i+1));
			System.out.println("Nome: ");
			String nome = input.nextLine();
			System.out.println("Telefono: ");
			String telefono = input.nextLine();
			System.out.println("Email: ");
			String email = input.nextLine();
			
			Contatto cont = new Contatto(nome, telefono, email);
			rubrica.add(cont);
						
		}
		
		System.out.println("##### RUBRICA COMPLETA #####");
		for(Contatto cont: rubrica) {
			cont.stampaContatto();
		}

	}

}
