
public class Contatto {
	
	private String nome;
	private String telefono;
	private String email;
	
	
	public Contatto(String nome, String telefono, String email) {
		
		this.nome = nome;
		this.telefono = telefono;
		this.email = email;
		
		
	}

	public void stampaContatto() {
		
		System.out.println("Nome: "+nome);
		System.out.println("Numero di telefono: "+telefono);
		System.out.println("Indirizzo email: "+email);
	}

	
	
}
