
public class Main {

	public static void main(String[] args) {
		
		Studente[] studente = new Studente[3];
		
		studente[0] = new Studente("Emilio", 23);
		studente[1] = new Studente("Luca", 16);
		studente[2] = new Studente("Gaetano", 25);
		
		System.out.println("###Studenti maggiorenni###");
		System.out.println();
		
		for (Studente s: studente) {
			
			if(s.isMaggiorenne()) {
				
				s.stampaInfo();
				
				
			}
			
			
			
		}
		

	}

}
