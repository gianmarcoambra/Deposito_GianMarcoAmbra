
public class Studente {
	
	private String nome;
	private int eta;
	
	public Studente(String nome, int eta) {
		
		this.nome = nome;
		this.eta = eta;
		
		
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getEta() {
		return eta;
	}

	public void setEta(int eta) {
		this.eta = eta;
	}
	
	public boolean isMaggiorenne() {
		
		return eta >= 18;
	}
	
	public void stampaInfo() {
		
		System.out.println("Nome: "+nome);
		System.out.println("Et�: "+eta);
		
	}

}
